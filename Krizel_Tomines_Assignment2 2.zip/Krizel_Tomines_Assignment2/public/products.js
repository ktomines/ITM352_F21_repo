var products =
[
{
    "brand": "Assam Milk Tea",
    "price": 5.00,
    "image": "assam.jpeg",
    "quantities_avaliable": 9
},
{
    "brand": "Rabbit Signature",
    "price": 5.00,
    "image": "rbtsig.jpeg",
    "quantities_avaliable": 9
},
{
    "brand": "Lychee Green Tea",
    "price": 5.00,
    "image":  "lycheegreen.jpeg",
    "quantities_avaliable": 9
},
{
    "brand": "Tiramisu Milk Tea",
    "price": 4.00,
    "image":  "tiramisu.jpeg",
    "quantities_avaliable": 9
},

{
    "brand": "Queen of Hearts Mojito",
    "price": 5.00,
    "image":  "mojito.jpeg",
    "quantities_avaliable": 9
}
]
// an array of the products i would like to sell 
